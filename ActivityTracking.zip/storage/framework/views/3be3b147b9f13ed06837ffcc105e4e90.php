<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="system">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia><?php echo e(config('app.name', 'ATS')); ?></title>

        <link rel="icon" type="image/jpeg" href="/images/moes-crest.jpg">

        <?php if(config('pwa.enabled')): ?>
            <link rel="manifest" href="<?php echo e(route('pwa.manifest')); ?>">
            <meta name="theme-color" content="<?php echo e(config('pwa.theme_color')); ?>">
            <meta name="application-name" content="<?php echo e(config('pwa.short_name')); ?>">
            <meta name="mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-status-bar-style" content="default">
            <meta name="apple-mobile-web-app-title" content="<?php echo e(config('pwa.short_name')); ?>">
            <link rel="apple-touch-icon" href="/pwa/icons/apple-touch-icon.png">
            
            <meta name="ats-pwa" content="enabled">
        <?php endif; ?>

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(nonce: Illuminate\Support\Facades\Vite::cspNonce()); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/theme-init.ts', 'resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\Users\DELL\Desktop\WORK\ATS\ats\resources\views/app.blade.php ENDPATH**/ ?>